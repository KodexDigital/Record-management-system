﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;
using System.IO;

public partial class _Account_01_Login : System.Web.UI.Page
{
    public string UserName, Password;
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        if (this.txtID.Text == "")
        {
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Please, I do not allow empty entry on Staff ID!');", true);
        }
        else if (this.txtMobileNo.Text == "")
        {
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Please, Ensure to enter your Mobile number, Ok!');", true);
        }
        else
        {
            this.Validate_User();
        }
       
    }

    private void Validate_User()
    {
        UserName = this.txtID.Text.ToString();

        string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        using (SqlConnection cn = new SqlConnection(constring))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT [STAFF_ID] FROM Staff_Registration_tbl WHERE STAFF_ID ='" + UserName.Trim() + "'", cn))
            {
                cmd.CommandType = CommandType.Text;
                cn.Open();
                SqlDataReader dr = cmd.ExecuteReader(); 
                if (dr.HasRows==true)
                {
                        this.Login();
                }
                    else
                    {
                        ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Invalid Login Detail.\\nLogin Failed!');", true);
                    }


                }
                cn.Close();  //SELECT * FROM `student` WHERE mark=(select max(mark) from student) &  SELECT MIN( price ) FROM table WHERE price > ( SELECT MIN( price ) FROM table )
            }
        }

    private void Login()
    {
        Password = this.txtMobileNo.Text.ToString();

        string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        using (SqlConnection cn = new SqlConnection(constring))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT [STAFF_ID],[MOBILE_NO],[F_NAME],[L_NAME],[DESIGNATION] FROM Staff_Registration_tbl WHERE STAFF_ID = '" + UserName.Trim() + "' AND  MOBILE_NO ='" + Password.Trim() + "'", cn))
            //("SELECT MAX (patient_id) as max_patient_id FROM patient_data ", cnz);
            {
                cmd.CommandType = CommandType.Text;
                cn.Open();
                SqlDataReader dr = cmd.ExecuteReader();  //SELECT * FROM `student` WHERE class='Six' ORDER BY mark DESC LIMIT 0,3 to display top 3 records
                if (dr.HasRows == true)
                {
                    dr.Read();

                    Session["_UserName_"] = dr["F_NAME"].ToString() + " " + dr["L_NAME"].ToString();
                    Session["_Designation_"] = dr["DESIGNATION"].ToString();
                    FormsAuthentication.RedirectFromLoginPage(txtMobileNo.Text, true);
                    Response.Redirect("ServerRedirect.aspx");

                }
                else
                {
                    ClientScript.RegisterStartupScript(GetType(), "alert", "alert('The System cannot Match your entry. Access Denied!');", true);
                }
                cn.Close();  //SELECT * FROM `student` WHERE mark=(select max(mark) from student) &  SELECT MIN( price ) FROM table WHERE price > ( SELECT MIN( price ) FROM table )
            }
        }
    }
}