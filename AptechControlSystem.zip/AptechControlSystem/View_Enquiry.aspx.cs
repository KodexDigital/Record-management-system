﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;
using System.IO;

public partial class _sector101_View_Enquiry : System.Web.UI.Page
{

    SqlDataAdapter da;
    DataSet ds;
    int i = 0;
    int j;
    int last;

    public string filePath;
    public string filename;
    public string ext;
    public string contenttype;

    public string UpdateHolder;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            this.lblSessionName.Text = "WELCOME, " + Session["_Designation_"].ToString() + " " + "[" + Session["_UserName_"].ToString() + "]" + ":" + System.DateTime.Now.ToLongDateString() + ".";
            
            this.BindData();

            this.ViewAllRecord();
           // this.ViewPassport();
        }
    }

    private void BindData()
    {
        try
        {
            string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            using (SqlConnection cn = new SqlConnection(constring))
            {
                cn.Open();
                da = new SqlDataAdapter("SELECT EnquiryNo, Title, FullName, Address, DOB, Gender, ContactNo, EmailID, ParentName, Education, CareerField, FuturePlan, ModeOfKnow, ITPlacement, CreationDate FROM Enquiry_tbl", cn);
                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                ds = new DataSet();
                da.Fill(ds, "Enquiry_tbl");
                // dataGridView1.DataSource = ds.Tables["emp"]
            }
            if (ds.Tables[0].Rows.Count > 0)
            {
                i = 0;
                this.txtTitle.Text = ds.Tables[0].Rows[i]["Title"].ToString();
                this.txtEnquiryNo.Text = ds.Tables[0].Rows[i]["EnquiryNo"].ToString();
                this.txtFName.Text = ds.Tables[0].Rows[i]["FullName"].ToString();
                this.txtAddress.Text = ds.Tables[0].Rows[i]["Address"].ToString();
                this.txtDOB.Text = ds.Tables[0].Rows[i]["DOB"].ToString();
                this.txtGender.Text = ds.Tables[0].Rows[i]["Gender"].ToString();
                this.txtNo.Text = ds.Tables[0].Rows[i]["ContactNo"].ToString();
                this.txtEmail.Text = ds.Tables[0].Rows[i]["EmailID"].ToString();
                this.txtParent_FName.Text = ds.Tables[0].Rows[i]["ParentName"].ToString();
                this.txtEdu.Text = ds.Tables[0].Rows[i]["Education"].ToString();
                this.txtCareer.Text = ds.Tables[0].Rows[i]["CareerField"].ToString();
                this.txtFPlan.Text = ds.Tables[0].Rows[i]["FuturePlan"].ToString();
                this.txtKnowMode.Text = ds.Tables[0].Rows[i]["ModeOfKnow"].ToString(); 
                this.txtITPlace.Text = ds.Tables[0].Rows[i]["ITPlacement"].ToString();
                this.txtEquiryDate.Text = ds.Tables[0].Rows[i]["CreationDate"].ToString(); 
            }
        }
        catch (SqlException ex)
        {
            ClientScript.RegisterClientScriptBlock((GetType()), "AlertBox", "alert('" + ex.ToString() + "');", true);
        }

        {
            string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            using (SqlConnection cn = new SqlConnection(constring))
            {
             using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) AS TotalEnquiry FROM Enquiry_tbl ", cn))
                {
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.HasRows == true)
                    {
                        dr.Read();
                        this.lblCountAll.Text = dr["TotalEnquiry"].ToString(); 
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Record not Found - It does not exist!');", true);
                    }


                }
                cn.Close();  //SELECT * FROM `student` WHERE mark=(select max(mark) from student) &  SELECT MIN( price ) FROM table WHERE price > ( SELECT MIN( price ) FROM table )
            }
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        if (this.txtSearch.Text == "")
        {
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('I cannot search am empty parameter for you!\\nPlease, double check your search and try again!');", true);
        }
        else
        { 
        string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        using (SqlConnection cn = new SqlConnection(constring))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT EnquiryNo, Title, FullName, Address, DOB, Gender, ContactNo, EmailID, ParentName, Education, CareerField, FuturePlan, ModeOfKnow, ITPlacement, CreationDate FROM Enquiry_tbl  WHERE ContactNo ='" + txtSearch.Text.ToString() + "' OR EmailID='" + txtSearch.Text.ToString() + "' ", cn))
            {
                cmd.CommandType = CommandType.Text;
                cn.Open();
                SqlDataReader dr = cmd.ExecuteReader(); 
                if (dr.HasRows==true)
                {
                    dr.Read();
                    this.txtTitle.Text = dr["Title"].ToString();
                    this.txtEnquiryNo.Text = dr["EnquiryNo"].ToString();
                    this.txtFName.Text = dr["FullName"].ToString();
                    this.txtAddress.Text = dr["Address"].ToString();
                    this.txtDOB.Text = dr["DOB"].ToString();
                    this.txtGender.Text = dr["Gender"].ToString();
                    this.txtNo.Text = dr["ContactNo"].ToString();
                    this.txtEmail.Text = dr["EmailID"].ToString();
                    this.txtParent_FName.Text = dr["ParentName"].ToString();
                    this.txtEdu.Text = dr["Education"].ToString();
                    this.txtCareer.Text = dr["CareerField"].ToString();
                    this.txtFPlan.Text = dr["FuturePlan"].ToString();
                    this.txtKnowMode.Text = dr["ModeOfKnow"].ToString();
                    this.txtITPlace.Text = dr["ITPlacement"].ToString();
                    this.txtEquiryDate.Text = dr["CreationDate"].ToString(); 

                    //Viewing Passport
                    this.ViewPassport();

                }
                    else
                    {
                        ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Record not Found - It does not exist!');", true);
                    }


                }
                cn.Close();  //SELECT * FROM `student` WHERE mark=(select max(mark) from student) &  SELECT MIN( price ) FROM table WHERE price > ( SELECT MIN( price ) FROM table )
            }
        }
    }

    private void ViewPassport()
    {
       string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
       using (SqlConnection cn = new SqlConnection(constring))
       {
           using (SqlCommand cmd = new SqlCommand("SELECT DataContent FROM Passport_tbl WHERE ContactNo ='" + txtSearch.Text.ToString() + "' OR EmailID='" + txtSearch.Text.ToString() + "' ", cn))
           {
               cn.Open();
               SqlDataReader dr = cmd.ExecuteReader();
               if (dr.Read())
               {
                   string imagename = dr["DataContent"].ToString();
                   imgPassort.ImageUrl = "~/Passport/" + imagename; 
                 
               }
               else
               {
                   imgPassort.ImageUrl = null;
                 ClientScript.RegisterClientScriptBlock(GetType(), "AlertBox", "alert('Passport not found. Not Uploaded Yet,...');", true);
                    //ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Record not Found - It does not exist!');", true);
               }
           }
           cn.Close();
       }
    }

    //protected void lnkBtnMoreView_Click(object sender, EventArgs e)
    //{
    //    bool buttonClicked = true;
    //    if (buttonClicked == true && this.lnkBtnMoreView.Text == "More View")
    //    {

    //    this.pnlViewMore.Visible = true;
    //    string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
    //    using (SqlConnection cn = new SqlConnection(constring))
    //    {
    //        cn.Open();
    //        da = new SqlDataAdapter("SELECT EnquiryNo, Title, FullName, Address, DOB, Gender, ContactNo, EmailID, ParentName, Education, CareerField, FuturePlan, ModeOfKnow, ITPlacement FROM Enquiry_tbl ORDER BY SN ASC", cn);
    //        SqlCommandBuilder builder = new SqlCommandBuilder(da);
    //        ds = new DataSet();
    //        da.Fill(ds, "Enquiry_tbl");
    //        gViewAll.DataSource = ds.Tables["Enquiry_tbl"];
    //    }


    //    this.lnkBtnMoreView.Text = "Roll Out";
    //    }

    //    else if (buttonClicked == true && this.lnkBtnMoreView.Text == "Roll Out")
    //    {
    //        this.pnlViewMore.Visible = false;
    //        this.lnkBtnMoreView.Text = "More View";
    //    }

    //}

    //private void ViewAllEnquiry()
    //{
    //    string constr = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
    //    string query = "SELECT Title, EnquiryNo, FullName, Address, DOB, Gender, ContactNo, EmailID, ParentName, Education, CareerField, FuturePlan, ModeOfKnow, ITPlacement FROM Enquiry_tbl ORDER BY SN ASC";
    //    //query += "SELECT TOP 10 (FirstName + ' ' + LastName) EmployeeName, City, Country FROM Employees";

    //    using (SqlConnection con = new SqlConnection(constr))
    //    {
    //        using (SqlCommand cmd = new SqlCommand(query))
    //        {
    //            using (SqlDataAdapter sda = new SqlDataAdapter())
    //            {
    //                cmd.Connection = con;
    //                sda.SelectCommand = cmd;
    //                using (DataSet ds = new DataSet())
    //                {
    //                    sda.Fill(ds);
    //                    gvDeposit.DataSource = ds.Tables[0];
    //                    gvDeposit.DataBind();
    //                    //gvEmployees.DataSource = ds.Tables[1];
    //                    //gvEmployees.DataBind();
    //                }
    //            }
    //        }
    //    }
    //}
    protected void lnkViewAll_Click(object sender, EventArgs e)
    {
       
    }

    private void ViewAllRecord()
    {
        string constr = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        string query = "SELECT Title, EnquiryNo, FullName, Address, DOB, Gender, ContactNo, EmailID, ParentName, Education, CareerField, FuturePlan, ModeOfKnow, ITPlacement FROM Enquiry_tbl ORDER BY SN ASC";

        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand(query))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.Connection = con;
                    sda.SelectCommand = cmd;
                    using (DataSet ds = new DataSet())
                    {
                        sda.Fill(ds);
                        gridViewAll.DataSource = ds.Tables[0];
                        gridViewAll.DataBind();
                    }
                }
            }
        }
    }

    //protected void OnPaging(object sender, GridViewPageEventArgs e)
    //{
    //    gridViewAll.PageIndex = e.NewPageIndex;
    //    this.SearchAllStudents();
    //}
    //private void SearchAllStudents()
    //{
    //    string constr = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
    //    using (SqlConnection con = new SqlConnection(constr))
    //    {
    //        using (SqlCommand cmd = new SqlCommand())
    //        {
    //            string sql = "SELECT Title, EnquiryNo, FullName, Address, DOB, Gender, ContactNo, EmailID, ParentName, Education, CareerField, FuturePlan, ModeOfKnow, ITPlacement FROM Enquiry_tbl";
    //            if (!string.IsNullOrEmpty(txtSearch.Text.Trim()))
    //            {
    //                sql += " WHERE ContactNo LIKE @ContactNo + '%'";
    //                cmd.Parameters.AddWithValue("@ContactNo", txtSearch.Text.Trim());
    //            }
    //            cmd.CommandText = sql;
    //            cmd.Connection = con;
    //            using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
    //            {
    //                DataTable dt = new DataTable();
    //                sda.Fill(dt);
    //                gridViewAll.DataSource = dt;
    //                gridViewAll.DataBind();
    //            }
    //        }
    //    }
    //}
//    protected void txtSearchGrid_TextChanged(object sender, EventArgs e)
//{
//    this.SearchAllStudents();
//        //SqlDataAdapter adapt;
//        //DataTable dt; 

//        //string constr = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
//        //string query = "SELECT Title, EnquiryNo, FullName, Address, DOB, Gender, ContactNo, EmailID, ParentName, Education, CareerField, FuturePlan, ModeOfKnow, ITPlacement FROM Enquiry_tbl ORDER BY SN ASC";

//        //using (SqlConnection con = new SqlConnection(constr))
//        //{
//        //    using (SqlCommand cmd = new SqlCommand(query))
//        //    {
//        //        using (SqlDataAdapter sda = new SqlDataAdapter())
//        //        {
//        //            adapt = new SqlDataAdapter("SELECT Title, EnquiryNo, FullName, Address, DOB, Gender, ContactNo, EmailID, ParentName, Education, CareerField, FuturePlan, ModeOfKnow, ITPlacement FROM Enquiry_tbl WHERE ContactNo like '" + txtSearch.Text.ToString() + "%' ", con); //OR EmailID like '" + txtSearch.Text.ToString() + "%' 
//        //            dt = new DataTable();   
//        //            adapt.Fill(dt);
//        //            gridViewAll.DataSource = dt;  
                    
                    
                    
//        //            //cmd.Connection = con;
//        //            //sda.SelectCommand = cmd;
//        //            //using (DataSet ds = new DataSet())
//        //            //{
//        //            //    sda.Fill(ds);
//        //            //    gridViewAll.DataSource = ds.Tables[0];
//        //            //    gridViewAll.DataBind();
//        //            //}
//        //        }
//        //    }
//        //}
//    }

}