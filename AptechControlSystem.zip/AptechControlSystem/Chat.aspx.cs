﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;
using System.Media;

public partial class _sector101_Chat : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            this.BindRepeaterData();
            timerRefreshPAge.Enabled = true;
        }

       // Response.AddHeader("Refresh", "1");
    }
    protected void GetTime(object sender, EventArgs e)
    {
        //lblTime.Text = DateTime.Now.ToString("hh:mm:ss tt");
        this.BindRepeaterData();
    }
    protected void BindRepeaterData()
    {
        string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        using (SqlConnection cn = new SqlConnection(constring))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT TOP (10)  * FROM Chat_tbl ORDER By SN DESC", cn))
            //("SELECT MAX (patient_id) as max_patient_id FROM patient_data ", cnz);
            {
                cmd.CommandType = CommandType.Text;
                cn.Open();
                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                RepDetails.DataSource = ds;
                RepDetails.DataBind();
                cn.Close();

                //SoundPlayer playthewavfile = new SoundPlayer(@"Sound\MsgNote.wav");
                //playthewavfile.Play();  

            }
        }

    }

    protected void SoundCreator()
    {
        string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        using (SqlConnection cn = new SqlConnection(constring))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT MAX(SN) AS Max_Id FROM Chat_tbl ORDER By SN DESC", cn))
            {
                cmd.CommandType = CommandType.Text;
                cn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows == true)
                {
                    SoundPlayer sd = new SoundPlayer();
                    sd.SoundLocation = Server.MapPath("~/Sound/MsgNote.wav");
                    sd.Play(); 
                }
                //else
                //{
                //    ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Invalid Login Detail.\\nLogin Failed!');", true);
                //}


            }
            cn.Close();  //SELECT * FROM `student` WHERE mark=(select max(mark) from student) &  SELECT MIN( price ) FROM table WHERE price > ( SELECT MIN( price ) FROM table )
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        using (SqlConnection cn = new SqlConnection(constring))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT DataContent FROM Audio_tbl WHERE SN = 1" , cn))
            {
                cn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                   // string imagename = dr["DataContent"].ToString();
                    SoundPlayer sd = new SoundPlayer();
                    sd.SoundLocation = Server.MapPath("~/Sound/MsgNote.wav");
                    sd.Play(); 

                }
            }
            cn.Close();
        }
    }
}