﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;
using System.IO;

public partial class View_Application : System.Web.UI.Page
{
    SqlDataAdapter da;
    DataSet ds;
    int i = 0;
    int j;
    int last;

    public string filePath;
    public string filename;
    public string ext;
    public string contenttype;

    public string UpdateHolder;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
           this.lblSessionName.Text = "WELCOME, " + Session["_Designation_"].ToString() + " " + "[" + Session["_UserName_"].ToString() + "]" + ":" + System.DateTime.Now.ToLongDateString() + ".";

            this.BindData();

            this.ViewAllRecord();
            // this.ViewPassport();
        }
    }
    private void BindData()
    {
        try
        {
            string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            using (SqlConnection cn = new SqlConnection(constring))
            {
                cn.Open();
                da = new SqlDataAdapter("SELECT SERIALNO, COURSEAPPLIED, TITLE, FULLNAME, ADDRESS, DOB, GENDER, CONTACTNO, P_ADDRESS, EMAIL_1, EMAIL_2, EDUCATION, XCURRICULUM, CREATEDDATE FROM Application_tbl", cn);
                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                ds = new DataSet();
                da.Fill(ds, "Application_tbl");
                // dataGridView1.DataSource = ds.Tables["emp"]
            }
            if (ds.Tables[0].Rows.Count > 0)
            {
                i = 0;
                this.txtTitle.Text = ds.Tables[0].Rows[i]["TITLE"].ToString();
                this.txtSerialNo.Text = ds.Tables[0].Rows[i]["SERIALNO"].ToString();
                this.txtFName.Text = ds.Tables[0].Rows[i]["FULLNAME"].ToString();
                this.txtCourse.Text = ds.Tables[0].Rows[i]["COURSEAPPLIED"].ToString();
                this.txtAddress.Text = ds.Tables[0].Rows[i]["ADDRESS"].ToString();
                this.txtDOB.Text = ds.Tables[0].Rows[i]["DOB"].ToString();
                this.txtGender.Text = ds.Tables[0].Rows[i]["GENDER"].ToString();
                this.txtNo.Text = ds.Tables[0].Rows[i]["CONTACTNO"].ToString();
                this.txtP_Address.Text = ds.Tables[0].Rows[i]["P_ADDRESS"].ToString();  
                this.txtEmail1.Text = ds.Tables[0].Rows[i]["EMAIL_1"].ToString();
                this.txtEmail2.Text = ds.Tables[0].Rows[i]["EMAIL_2"].ToString();
                this.txtEdu.Text = ds.Tables[0].Rows[i]["EDUCATION"].ToString();
                this.txtXcurriculum.Text = ds.Tables[0].Rows[i]["XCURRICULUM"].ToString();
                this.txtApplicationDate.Text = ds.Tables[0].Rows[i]["CREATEDDATE"].ToString(); 
            }
        }
        catch (SqlException ex)
        {
            ClientScript.RegisterClientScriptBlock((GetType()), "AlertBox", "alert('" + ex.ToString() + "');", true);
        }

        {
            string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            using (SqlConnection cn = new SqlConnection(constring))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) AS TotalApplicant FROM Application_tbl ", cn))
                {
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.HasRows == true)
                    {
                        dr.Read();
                        this.lblCountAll.Text = dr["TotalApplicant"].ToString();
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Record not Found - It does not exist!');", true);
                    }


                }
                cn.Close();  //SELECT * FROM `student` WHERE mark=(select max(mark) from student) &  SELECT MIN( price ) FROM table WHERE price > ( SELECT MIN( price ) FROM table )
            }
        }
    }
    private void ViewAllRecord()
    {
        string constr = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        string query = "SELECT SERIALNO, COURSEAPPLIED, TITLE, FULLNAME, ADDRESS, DOB, GENDER, CONTACTNO, P_ADDRESS, EMAIL_1, EMAIL_2, EDUCATION, XCURRICULUM FROM Application_tbl ORDER BY SN ASC";

        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand(query))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.Connection = con;
                    sda.SelectCommand = cmd;
                    using (DataSet ds = new DataSet())
                    {
                        sda.Fill(ds);
                        gridViewAll.DataSource = ds.Tables[0];
                        gridViewAll.DataBind();
                    }
                }
            }
        }
    }

    private void ViewPassport()
    {
        string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        using (SqlConnection cn = new SqlConnection(constring))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT DataContent FROM Passport_tbl WHERE ContactNo ='" + txtSearch.Text.ToString() + "' OR EmailID='" + txtSearch.Text.ToString() + "' ", cn))
            {
                cn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string imagename = dr["DataContent"].ToString();
                    imgPassort.ImageUrl = "~/Passport/" + imagename;

                }
                else
                {
                    imgPassort.ImageUrl = null;
                    ClientScript.RegisterClientScriptBlock(GetType(), "AlertBox", "alert('Passport not found. Not Uploaded Yet,...');", true);
                    //ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Record not Found - It does not exist!');", true);
                }
            }
            cn.Close();
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        if (this.txtSearch.Text == "")
        {
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('I cannot search am empty parameter for you!\\nPlease, double check your search and try again!');", true);
        }
        else
        {
            string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            using (SqlConnection cn = new SqlConnection(constring))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT SERIALNO, COURSEAPPLIED, TITLE, FULLNAME, ADDRESS, DOB, GENDER, CONTACTNO, P_ADDRESS, EMAIL_1, EMAIL_2, EDUCATION, XCURRICULUM, CREATEDDATE FROM Application_tbl  WHERE CONTACTNO ='" + txtSearch.Text.ToString() + "' OR EMAIL_1='" + txtSearch.Text.ToString() + "' ", cn))
                {
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.HasRows == true)
                    {
                        dr.Read();
                        this.txtTitle.Text = dr["TITLE"].ToString();
                        this.txtSerialNo.Text = dr["SERIALNO"].ToString();
                        this.txtFName.Text = dr["FULLNAME"].ToString();
                        this.txtCourse.Text = dr["COURSEAPPLIED"].ToString();
                        this.txtAddress.Text = dr["ADDRESS"].ToString();
                        this.txtDOB.Text = dr["DOB"].ToString();
                        this.txtGender.Text = dr["GENDER"].ToString();
                        this.txtNo.Text = dr["CONTACTNO"].ToString();
                        this.txtP_Address.Text = dr["P_ADDRESS"].ToString();
                        this.txtEmail1.Text = dr["EMAIL_1"].ToString();
                        this.txtEmail2.Text = dr["EMAIL_2"].ToString();
                        this.txtEdu.Text = dr["EDUCATION"].ToString();
                        this.txtXcurriculum.Text = dr["XCURRICULUM"].ToString();
                        this.txtApplicationDate.Text = dr["CREATEDDATE"].ToString(); 


                        //Viewing Passport
                        this.ViewPassport();

                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Record not Found - It does not exist!');", true);
                    }


                }
                cn.Close();  //SELECT * FROM `student` WHERE mark=(select max(mark) from student) &  SELECT MIN( price ) FROM table WHERE price > ( SELECT MIN( price ) FROM table )
            }
        }
    }
}