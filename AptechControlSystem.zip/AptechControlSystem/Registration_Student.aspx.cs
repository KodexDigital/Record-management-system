﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;
using System.IO;

public partial class _sector101_Registration_Student : System.Web.UI.Page
{
    public string SERIALNO, COURSEAPPLIED, TITLE, FULLNAME, ADDRESS, DOB, GENDER, CONTACTNO, EMAIL, EDUCATION, XCRURRICULUM, FACEBOOK, INTAGRAM, LINKED_IN, WHATSAPP, KNOWMODE, CREATEDDATE, CREATEDBY;
    public string GetEdu;
    public string GetModeKnow;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack && Session["_UserName_"] != null)
        {
            this.lblSessionName.Text = "WELCOME, " + Session["_Designation_"].ToString() + " " + "[" + Session["_UserName_"].ToString() + "]" + ":" + System.DateTime.Now.ToLongDateString() + ".";
            this.LoadCourseCategory();
        }
        else
        {
            FormsAuthentication.RedirectToLoginPage();
        }
    }
    private void LoadCourseCategory()
    {
        string constr = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT [DESCRIPTION],[CATEGORY] FROM [CourseCategory_tbl]", con))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {

                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    this.dropCourse.DataSource = dt;
                    dropCourse.DataTextField = "DESCRIPTION";
                    dropCourse.DataValueField = "CATEGORY";
                    dropCourse.DataBind();
                    dropCourse.Items.Insert(0, new ListItem("COURSE APPLIED FOR:"));


                }
            }
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (this.dropCourse.Text == "COURSE APPLIED FOR:")
        {
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('What COURSE is the Student applying for?');", true);
        }
        if (this.dropTitle.Text == "SELECT")
        {
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('Please, kindly supply the Title.');", true);
        }
        else if (this.dropGender.Text == "SELECT")
        {
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('What is the GENDER of the student?');", true);
        }
        else if (this.txEmail.Text == "")
        {
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('What is the E-mail Address of the Student?');", true);
        }
        else if (Session["_Edu"] == null)
        {
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('No Selection made for Education Yet!');", true);
        }
        else
        {
            //ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('Good to Go');", true);

            SERIALNO = this.txtSerialNo.Text.ToString();
            COURSEAPPLIED = this.dropCourse.Text.ToString();
            TITLE = this.dropTitle.Text.ToString();
            FULLNAME = this.txtFullName.Text.ToString();
            ADDRESS = this.txtAddress.Text.ToString();
            DOB = this.txtDOB.Text.ToString();
            GENDER = this.dropGender.Text.ToString();
            CONTACTNO = this.txtContact.Text.ToString();
            EMAIL = this.txEmail.Text.ToString();
            EDUCATION = Session["_Edu"].ToString();
            XCRURRICULUM = this.txtXtraCuriculum.Text.ToString();
            FACEBOOK = this.txtFacbook.Text.ToString();
            INTAGRAM = this.txtInstagram.Text.ToString();
            LINKED_IN = this.txtLinkedIn.Text.ToString();
            WHATSAPP = this.txtWatsapp.Text.ToString();
            KNOWMODE = Session["_KnowMode"].ToString();
            CREATEDDATE = System.DateTime.Now.ToLongDateString();
            CREATEDBY = Session["_UserName_"].ToString();


            string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constring))
            {
                using (SqlCommand cmd = new SqlCommand("INSERT INTO RegistrationStudent_tbl (SERIALNO, COURSEAPPLIED, TITLE, FULLNAME, ADDRESS, DOB, GENDER, CONTACTNO, EMAIL, EDUCATION, XCRURRICULUM, FACEBOOK, INTAGRAM, LINKED_IN, WHATSAPP, KNOWMODE, CREATEDDATE, CREATEDBY) VALUES (@SERIALNO, @COURSEAPPLIED, @TITLE, @FULLNAME, @ADDRESS, @DOB, @GENDER, @CONTACTNO, @EMAIL, @EDUCATION, @XCRURRICULUM, @FACEBOOK, @INTAGRAM, @LINKED_IN, @WHATSAPP, @KNOWMODE, @CREATEDDATE, CREATEDBY)", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@SERIALNO", SERIALNO.Trim());
                    cmd.Parameters.AddWithValue("@COURSEAPPLIED", COURSEAPPLIED.Trim());
                    cmd.Parameters.AddWithValue("@TITLE", TITLE.Trim());
                    cmd.Parameters.AddWithValue("@FULLNAME", FULLNAME.Trim());
                    cmd.Parameters.AddWithValue("@ADDRESS", ADDRESS.Trim());
                    cmd.Parameters.AddWithValue("@DOB", DOB.Trim());
                    cmd.Parameters.AddWithValue("@GENDER", GENDER.Trim());
                    cmd.Parameters.AddWithValue("@CONTACTNO", CONTACTNO.Trim());
                    cmd.Parameters.AddWithValue("@EMAIL", EMAIL.Trim());
                    cmd.Parameters.AddWithValue("@EDUCATION", EDUCATION.Trim());
                    cmd.Parameters.AddWithValue("@XCRURRICULUM", XCRURRICULUM.Trim());
                    cmd.Parameters.AddWithValue("@FACEBOOK", FACEBOOK.Trim());
                    cmd.Parameters.AddWithValue("@INTAGRAM", INTAGRAM.Trim());
                    cmd.Parameters.AddWithValue("@LINKED_IN", LINKED_IN.Trim());
                    cmd.Parameters.AddWithValue("@WHATSAPP", WHATSAPP.Trim());
                    cmd.Parameters.AddWithValue("@KNOWMODE", KNOWMODE.Trim());
                    cmd.Parameters.AddWithValue("@CREATEDDATE", CREATEDDATE.Trim());
                    cmd.Parameters.AddWithValue("@CREATEDBY", CREATEDBY.Trim());
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    Response.Redirect("Success_RegistrationStudent.aspx");
                    Session.RemoveAll();

                    // Label1.Text = "Data Save Successfully and Recorded";

                    con.Close();

                }
            }
        }
    }
    protected void chkSSCE_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkSSCE.Checked == true)
        {
            GetEdu = "SSCE".ToString();
            lblEduShow.Text = GetEdu;
            Session["_Edu"] = lblEduShow.Text.ToString();
        }
        else
        {
            lblEduShow.Text = "";
            Session["_Edu"] = null;
        }
    }
    protected void chkHighWAEC_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkHighWAEC.Checked == true)
        {
            GetEdu = "WAEC".ToString();
            lblEduShow.Text = GetEdu;
            Session["_Edu"] = lblEduShow.Text.ToString();
        }
        else
        {
            lblEduShow.Text = "";
            Session["_Edu"] = null;
        }
    }
    protected void chkOND_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkOND.Checked == true)
        {
            GetEdu = "OND".ToString();
            lblEduShow.Text = GetEdu;
            Session["_Edu"] = lblEduShow.Text.ToString();
        }
        else
        {
            lblEduShow.Text = "";
            Session["_Edu"] = null;
        }
    }
    protected void chkHND_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkHND.Checked == true)
        {
            GetEdu = "HND".ToString();
            lblEduShow.Text = GetEdu;
            Session["_Edu"] = lblEduShow.Text.ToString();
        }
        else
        {
            lblEduShow.Text = "";
            Session["_Edu"] = null;
        }
    }
    protected void chkBSC_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkBSC.Checked == true)
        {
            GetEdu = "B.SC.".ToString();
            lblEduShow.Text = GetEdu;
            Session["_Edu"] = lblEduShow.Text.ToString();
        }
        else
        {
            lblEduShow.Text = "";
            Session["_Edu"] = null;
        }
    }
    protected void chkMSC_CheckedChanged(object sender, EventArgs e)
    {

        if (this.chkMSC.Checked == true)
        {
            GetEdu = "MSC.".ToString();
            lblEduShow.Text = GetEdu;
            Session["_Edu"] = lblEduShow.Text.ToString();
        }
        else
        {
            lblEduShow.Text = "";
            Session["_Edu"] = null;
        }
    }
    protected void chkPHD_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkPHD.Checked == true)
        {
            GetEdu = "PHD.".ToString();
            lblEduShow.Text = GetEdu;
            Session["_Edu"] = lblEduShow.Text.ToString();
        }
        else
        {
            lblEduShow.Text = "";
            Session["_Edu"] = null;
        }
    }
    protected void chkNCE_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkNCE.Checked == true)
        {
            GetEdu = "NCE".ToString();
            lblEduShow.Text = GetEdu;
            Session["_Edu"] = lblEduShow.Text.ToString();
        }
        else
        {
            lblEduShow.Text = "";
            Session["_Edu"] = null;
        }
    }
    protected void chkEduOther_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkEduOther.Checked == true)
        {
            GetEdu = "OTHER".ToString();
            lblEduShow.Text = GetEdu;
            Session["_Edu"] = lblEduShow.Text.ToString();
        }
        else
        {
            lblEduShow.Text = "";
            Session["_Edu"] = null;
        }
    }
    protected void chkSeminar_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkSeminar.Checked == true)
        {
            GetModeKnow = "SEMINAR".ToString();
            lblEduKnowMode.Text = GetModeKnow;
            Session["_KnowMode"] = lblEduKnowMode.Text.ToString();
        }
        else
        {
            lblEduKnowMode.Text = "";
            Session["_KnowMode"] = null;
        }
    }
    protected void chkCinema_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkCinema.Checked == true)
        {
            GetModeKnow = "CINEMA".ToString();
            lblEduKnowMode.Text = GetModeKnow;
            Session["_KnowMode"] = lblEduKnowMode.Text.ToString(); 
        }
        else
        {
            lblEduKnowMode.Text = "";
            Session["_KnowMode"] = null;
        }
    }
    protected void chkNewspaper_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkNewspaper.Checked == true)
        {
            GetModeKnow = "NEWSPAPER".ToString();
            lblEduKnowMode.Text = GetModeKnow;
            Session["_KnowMode"] = lblEduKnowMode.Text.ToString();
        }
        else
        {
            lblEduKnowMode.Text = "";
            Session["_KnowMode"] = null;
        }
    }
    protected void chkFriends_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkFriends.Checked == true)
        {
            GetModeKnow = "FRIENDS/RELATIVES".ToString();
            lblEduKnowMode.Text = GetModeKnow;
            Session["_KnowMode"] = lblEduKnowMode.Text.ToString();
        }
        else
        {
            lblEduKnowMode.Text = "";
            Session["_KnowMode"] = null;
        }
    }
    protected void chkMagazine_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkMagazine.Checked == true)
        {
            GetModeKnow = "MAGAZINE".ToString();
            lblEduKnowMode.Text = GetModeKnow;
            Session["_KnowMode"] = lblEduKnowMode.Text.ToString();
        }
        else
        {
            lblEduKnowMode.Text = "";
            Session["_KnowMode"] = null;
        }
    }
    protected void chkInternet_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkInternet.Checked == true)
        {
            GetModeKnow = "INTERNET".ToString();
            lblEduKnowMode.Text = GetModeKnow;
            Session["_KnowMode"] = lblEduKnowMode.Text.ToString();
        }
        else
        {
            lblEduKnowMode.Text = "";
            Session["_KnowMode"] = null;
        }
    }
    protected void chkExistingStudent_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkExistingStudent.Checked == true)
        {
            GetModeKnow = "EXISTING STUDENT".ToString();
            lblEduKnowMode.Text = GetModeKnow;
            Session["_KnowMode"] = lblEduKnowMode.Text.ToString();
        }
        else
        {
            lblEduKnowMode.Text = "";
            Session["_KnowMode"] = null;
        }
    }
    protected void chkModeOther_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkModeOther.Checked == true)
        {
            GetModeKnow = "OTHER".ToString();
            lblEduKnowMode.Text = GetModeKnow;
            Session["_KnowMode"] = lblEduKnowMode.Text.ToString();
        }
        else
        {
            lblEduKnowMode.Text = "";
            Session["_KnowMode"] = null;
        }
    }
}