﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;
using System.Media;

public partial class _sector101_GroupChat : System.Web.UI.Page
{
    public string uSERId, cHatMsg, cHatDate, mSGId, msgID;
    Random rdn = new Random();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!this.IsPostBack && Session["_UserName_"] != null)
        {
            
            this.txtSend.Focus();

           // txtSend.Text = min.ToString() + "/" + max.ToString();
        }
        //else
        //{
        //    FormsAuthentication.RedirectToLoginPage();
        //}

    }

    private void AccessKey_Generate()
    {
        //Generate Alphanumeric random numbers
        Guid g = Guid.NewGuid();
        string random = g.ToString();
        msgID = random.Substring(0, 2);
        mSGId = Session["_Designation_"].ToString() + "<>" + msgID.ToString();
    }

    private void PostMessageInForum()
    {
        this.AccessKey_Generate();

        uSERId = Session["_UserName_"].ToString();
        cHatDate = System.DateTime.Today.ToShortDateString(); 
        cHatMsg = this.txtSend.Text.ToString();


        string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constring))
        {
            using (SqlCommand cmd = new SqlCommand("INSERT INTO Chat_tbl (uSERId,cHatMsg,mSGId,cHatDate) VALUES (@uSERId,@cHatMsg,@mSGId,@cHatDate)", con))
            {
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@uSERId", uSERId.Trim());
                cmd.Parameters.AddWithValue("@cHatMsg",cHatMsg.ToString());
                 cmd.Parameters.AddWithValue("@mSGId", mSGId.Trim());
                cmd.Parameters.AddWithValue("@cHatDate", cHatDate.ToString());
                con.Open();
                int rowsAffected = cmd.ExecuteNonQuery();


                this.txtSend.Text = string.Empty; 
                this.txtSend.Focus();

                // this.BindRepeaterData();


                con.Close();

            }
        }

    }

    protected void SoundCreator()
    {
        string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        using (SqlConnection cn = new SqlConnection(constring))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT MAX(SN) FROM Chat_tbl", cn))
            {
                cmd.CommandType = CommandType.Text;
                cn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows == true)
                {
                    SoundPlayer sd = new SoundPlayer();
                    sd.SoundLocation = Server.MapPath("~/Sound/MsgNote.wav");
                    sd.Play();
                }
                //else
                //{
                //    ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Invalid Login Detail.\\nLogin Failed!');", true);
                //}


            }
            cn.Close();  //SELECT * FROM `student` WHERE mark=(select max(mark) from student) &  SELECT MIN( price ) FROM table WHERE price > ( SELECT MIN( price ) FROM table )
        }

    }
    protected void btnPost_Click(object sender, EventArgs e)
    {
        bool buttonClicked = true;
        if (buttonClicked == true)
        {
            if (this.txtSend.Text == string.Empty) 
            {
                this.lblErrInfo.Text = "Please enter your message";
            }
            else
            {
                this.lblErrInfo.Text = string.Empty;
                this.PostMessageInForum();
                this.SoundCreator();
            }
        }
    }
}