﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;
using System.IO;

public partial class _sector101_Application : System.Web.UI.Page
{
    public string SERIALNO, COURSEAPPLIED, TITLE, FULLNAME, ADDRESS, DOB, GENDER, CONTACTNO, P_ADDRESS, EMAIL_1, EMAIL_2, EDUCATION, XCURRICULUM, CREATEDDATE, CREATEDBY;

    public string GetEdu;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack && Session["_UserName_"] != null)
        {
            this.lblSessionName.Text = "WELCOME, " + Session["_Designation_"].ToString() + " " + "[" + Session["_UserName_"].ToString() + "]" + ":" + System.DateTime.Now.ToLongDateString() + ".";
            this.LoadCourseCategory();
        }
        else
        {
            FormsAuthentication.RedirectToLoginPage();
        }
    }

    private void LoadCourseCategory()
    {
        string constr = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT [DESCRIPTION],[CATEGORY] FROM [CourseCategory_tbl]", con))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {

                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    this.dropCourse.DataSource = dt;
                    dropCourse.DataTextField = "DESCRIPTION";
                    dropCourse.DataValueField = "CATEGORY";
                    dropCourse.DataBind();
                    dropCourse.Items.Insert(0, new ListItem("COURSE APPLIED FOR:"));


                }
            }
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (this.dropCourse.Text == "COURSE APPLIED FOR:") 
        {
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('What COURSE is the Student applying for?');", true);
        }
        if (this.dropTitle.Text == "SELECT")
        {
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('Please, kindly supply the Title.');", true);
        }
        else if (this.dropGender.Text == "SELECT")
        {
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('What is the GENDER of the student?');", true);
        }
        else if (this.txEmail1.Text == "") 
        {
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('What is the E-mail Address of the Student?');", true);
        }
        else if (Session["_Edu"] == null)
        {
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('No Selection made for Education Yet!');", true);
        }
        else
        {
            //ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('Good to Go');", true);

            SERIALNO = this.txtSerialNo.Text.ToString();
            COURSEAPPLIED = this.dropCourse.Text.ToString();
            TITLE = this.dropTitle.Text.ToString();
            FULLNAME = this.txtFullName.Text.ToString();
            ADDRESS = this.txtAddress.Text.ToString();
            DOB = this.txtDOB.Text.ToString(); 
            GENDER = this.dropGender.Text.ToString();
            CONTACTNO = this.txtContact.Text.ToString();
            P_ADDRESS = this.txtPAddress.Text.ToString();
            EMAIL_1 = this.txEmail1.Text.ToString();
            EMAIL_2 = this.txEmail2.Text.ToString();
            EDUCATION = Session["_Edu"].ToString();
            XCURRICULUM = this.txtXtraCuriculum.Text.ToString(); 
            CREATEDDATE = System.DateTime.Now.ToLongDateString();
            CREATEDBY = Session["_UserName_"].ToString();


            string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constring))
            {
                using (SqlCommand cmd = new SqlCommand("INSERT INTO Application_tbl (SERIALNO, COURSEAPPLIED, TITLE, FULLNAME, ADDRESS, DOB, GENDER, CONTACTNO, P_ADDRESS, EMAIL_1, EMAIL_2, EDUCATION, XCURRICULUM, CREATEDDATE, CREATEDBY) VALUES (@SERIALNO, @COURSEAPPLIED, @TITLE, @FULLNAME, @ADDRESS, @DOB, @GENDER, @CONTACTNO, @P_ADDRESS, @EMAIL_1, @EMAIL_2, @EDUCATION, @XCURRICULUM, @CREATEDDATE, @CREATEDBY)", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@SERIALNO", SERIALNO.Trim());
                    cmd.Parameters.AddWithValue("@COURSEAPPLIED", COURSEAPPLIED.Trim());
                    cmd.Parameters.AddWithValue("@TITLE", TITLE.Trim());
                    cmd.Parameters.AddWithValue("@FULLNAME", FULLNAME.Trim());
                    cmd.Parameters.AddWithValue("@ADDRESS", ADDRESS.Trim());
                    cmd.Parameters.AddWithValue("@DOB", DOB.Trim());
                    cmd.Parameters.AddWithValue("@GENDER", GENDER.Trim());
                    cmd.Parameters.AddWithValue("@CONTACTNO", CONTACTNO.Trim());
                    cmd.Parameters.AddWithValue("@P_ADDRESS", P_ADDRESS.Trim());
                    cmd.Parameters.AddWithValue("@EMAIL_1", EMAIL_1.Trim());
                    cmd.Parameters.AddWithValue("@EMAIL_2", EMAIL_2.Trim());
                    cmd.Parameters.AddWithValue("@EDUCATION", EDUCATION.Trim());
                    cmd.Parameters.AddWithValue("@XCURRICULUM", XCURRICULUM.Trim());
                    cmd.Parameters.AddWithValue("@CREATEDDATE", CREATEDDATE.Trim());
                    cmd.Parameters.AddWithValue("@CREATEDBY", CREATEDBY.Trim());
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    Response.Redirect("Success_Application.aspx");
                    Session.RemoveAll();

                    // Label1.Text = "Data Save Successfully and Recorded";

                    con.Close();

                }
            }
        }
    }
    protected void chkSecondary_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkSecondary.Checked == true)
        {
            GetEdu = "Secondary".ToString();
            lblEduShow.Text = GetEdu;
            Session["_Edu"] = lblEduShow.Text.ToString();
        }
        else
        {
            lblEduShow.Text = "";
            Session["_Edu"] = null;
        }
    }
    protected void chkHighSch_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkHighSch.Checked == true)
        {
            GetEdu = "High School".ToString();
            lblEduShow.Text = GetEdu;
            Session["_Edu"] = lblEduShow.Text.ToString();
        }
        else
        {
            lblEduShow.Text = "";
            Session["_Edu"] = null;
        }
    }
    protected void chkGraduate_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkGraduate.Checked == true)
        {
            GetEdu = "Graduate".ToString();
            lblEduShow.Text = GetEdu;
            Session["_Edu"] = lblEduShow.Text.ToString();
        }
        else
        {
            lblEduShow.Text = "";
            Session["_Edu"] = null;
        }
    }
    protected void chkUnderGra_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkUnderGra.Checked == true)
        {
            GetEdu = "Undergraduate".ToString();
            lblEduShow.Text = GetEdu;
            Session["_Edu"] = lblEduShow.Text.ToString();
        }
        else
        {
            lblEduShow.Text = "";
            Session["_Edu"] = null;
        }
    }
    protected void chkVocation_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkVocation.Checked == true)
        {
            GetEdu = "Vocational School".ToString();
            lblEduShow.Text = GetEdu;
            Session["_Edu"] = lblEduShow.Text.ToString();
        }
        else
        {
            lblEduShow.Text = "";
            Session["_Edu"] = null;
        }
    }
    protected void chkOther_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkOther.Checked == true)
        {
            GetEdu = "Other".ToString();
            lblEduShow.Text = GetEdu;
            Session["_Edu"] = lblEduShow.Text.ToString();
        }
        else
        {
            lblEduShow.Text = "";
            Session["_Edu"] = null;
        }

    }
}