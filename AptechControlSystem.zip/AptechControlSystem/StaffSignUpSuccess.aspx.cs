﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _sector101_StaffSignUpSuccess : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            //System.Threading.Thread.Sleep(70000);
            this.lblCaptureName.Text = Session["_StaffName"].ToString();
            //Response.Redirect("../_Account_01/Login.aspx");
            
            

            this.Timer_Success.Enabled = true;
            this.Timer_Success.Interval = 30000;
            
        }
    }
    protected void btnSuccess_Click(object sender, EventArgs e)
    {
        Response.Redirect("../_Account_01/Login.aspx");
        Session.RemoveAll();
    }
    protected void Timer_Success_Tick(object sender, EventArgs e)
    {
        if (this.Timer_Success.Interval == 30000)
        {
            lblProcess.Text = "Work Space Created Successfully";
            this.btnSuccess.Visible = true;

            this.Timer_Success.Enabled = false;
        }
    }
}