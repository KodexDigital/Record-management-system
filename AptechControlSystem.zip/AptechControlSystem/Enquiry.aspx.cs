﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;
using System.IO;

public partial class _sector101_Enquiry : System.Web.UI.Page
{
    public string EnquiryNo, Title_, FullName, Address, DOB, Gender, ContactNo, EmailID, ParentName, Education, CareerField, FuturePlan, ModeOfKnow, ITPlacement, CreationDate, CreatedBy;

    public string GetGender;
    public string GetEdu;
    public string GetCareer;
    public string GetFuturePlan;
    public string GetModeKnow;
    public string GetPlacement;

    public string filePath;
    public string filename;
    public string ext;
    public string contenttype;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            this.lblSessionName.Text = "WELCOME, " + Session["_Designation_"].ToString() + " " + "[" + Session["_UserName_"].ToString() + "]" + ":" + System.DateTime.Now.ToLongDateString() + ".";
            this.lblDate_Today.Text = System.DateTime.Now.ToLongDateString();
        }
        //else
        //{
        //    FormsAuthentication.RedirectToLoginPage();
        //}
    }

    public void LinkData_Design()
    {
        EnquiryNo = this.txtEnquiryNo.Text.ToString();
        Title_ = this.dropTitle.Text.ToString();
        FullName = this.txtFullName.Text.ToString();
        Address = this.txtAddress.Text.ToString();
        DOB = this.txtDOB.Text.ToString();
        Gender = this.dropGender.Text.ToString(); 
        ContactNo = this.txtContact.Text.ToString();
        EmailID = this.txtEmail.Text.ToString();
        ParentName = this.txtGuardianName.Text.ToString();
        Education = GetEdu.ToString();
        CareerField = GetCareer.ToString();
        FuturePlan = GetFuturePlan.ToString();
        ModeOfKnow = GetModeKnow.ToString();
        ITPlacement = GetPlacement.ToString();
        CreationDate = this.lblDate_Today.Text.ToString();


    }

    private void InsertToDataBase()
    {
        //this.LinkData_Design();

        EnquiryNo = this.txtEnquiryNo.Text.ToString();
        Title_ = this.dropTitle.Text.ToString();
        FullName = this.txtFullName.Text.ToString();
        Address = this.txtAddress.Text.ToString();
        DOB = this.txtDOB.Text.ToString();
        Gender = this.dropGender.Text.ToString();
        ContactNo = this.txtContact.Text.ToString();
        EmailID = this.txtEmail.Text.ToString();
        ParentName = this.txtGuardianName.Text.ToString();
        Education = GetEdu.ToString();
        CareerField = GetCareer.ToString();
        FuturePlan = GetFuturePlan.ToString();
        ModeOfKnow = GetModeKnow.ToString();
        ITPlacement = GetPlacement.ToString();
        CreationDate = this.lblDate_Today.Text.ToString();

       

    }

    //Educational Background
    protected void chkSecondary_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkSecondary.Checked == true)
        {
            GetEdu = "Secondary".ToString();
            lblEduShow.Text = GetEdu;
            Session["_Edu"] = lblEduShow.Text.ToString();
        }
        else
        {
            lblEduShow.Text = "";
            Session["_Edu"] = null;
        }
    }
    protected void chkHighSch_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkHighSch.Checked == true)
        {
            GetEdu = "High School".ToString();
            lblEduShow.Text = GetEdu;
            Session["_Edu"] = lblEduShow.Text.ToString();
        }
        else
        {
            lblEduShow.Text = "";
            Session["_Edu"] = null;
        }
    }
    protected void chkGraduate_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkGraduate.Checked == true)
        {
            GetEdu = "Graduate".ToString();
            lblEduShow.Text = GetEdu;
            Session["_Edu"] = lblEduShow.Text.ToString();
        }
        else
        {
            lblEduShow.Text = "";
            Session["_Edu"] = null;
        }
    }
    protected void chkUnderGra_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkUnderGra.Checked == true)
        {
            GetEdu = "Undergraduate".ToString();
            lblEduShow.Text = GetEdu;
            Session["_Edu"] = lblEduShow.Text.ToString();
        }
        else
        {
            lblEduShow.Text = "";
            Session["_Edu"] = null;
        }
    }
    protected void chkVocation_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkVocation.Checked == true)
        {
            GetEdu =  "Vocational School".ToString() ;
            lblEduShow.Text = GetEdu;
            Session["_Edu"] = lblEduShow.Text.ToString();
        }
        else
        {
            lblEduShow.Text = "";
            Session["_Edu"] = null;
        }
    }
    protected void chkOther_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkOther.Checked == true)
        {
            GetEdu = "Other".ToString();
            lblEduShow.Text = GetEdu;
            Session["_Edu"] = lblEduShow.Text.ToString();
        }
        else
        {
            lblEduShow.Text = "";
            Session["_Edu"] = null;
        }
    }

    //Career Plan
    protected void chkMkt_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkMkt.Checked == true)
        {
            GetCareer = "Marketing".ToString();
            lblCareerShow.Text = GetCareer;
            Session["_Career"] = lblCareerShow.Text.ToString();
        }
        else
        {
            lblCareerShow.Text = "";
            Session["_Career"] = null;
        }
    }
    protected void chkSysEngr_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkSysEngr.Checked == true)
        {
            GetCareer = "System Engineering".ToString();
            lblCareerShow.Text = GetCareer;
            Session["_Career"] = lblCareerShow.Text.ToString();
        }
        else
        {
            lblCareerShow.Text = "";
            Session["_Career"] = null;
        }
    }
    protected void chkWebsite_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkWebsite.Checked == true)
        {
            GetCareer = "Website Design".ToString();
            lblCareerShow.Text = GetCareer;
            Session["_Career"] = lblCareerShow.Text.ToString();
        }
        else
        {
            lblCareerShow.Text = "";
            Session["_Career"] = null;
        }
    }
    protected void chkSoftPrograming_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkSoftPrograming.Checked == true)
        {
            GetCareer = "Software Programming".ToString();
            lblCareerShow.Text = GetCareer;
            Session["_Career"] = lblCareerShow.Text.ToString();
        }
        else
        {
            lblCareerShow.Text = "";
            Session["_Career"] = null;
        }
    }
    protected void chkHardware_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkHardware.Checked == true)
        {
            GetCareer = "Hardware/Networking".ToString();
            lblCareerShow.Text = GetCareer;
            Session["_Career"] = lblCareerShow.Text.ToString();
        }
        else
        {
            lblCareerShow.Text = "";
            Session["_Career"] = null;
        }
    }
    protected void chkEdu_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkEdu.Checked == true)
        {
            GetCareer = "Education".ToString();
            lblCareerShow.Text = GetCareer;
            Session["_Career"] = lblCareerShow.Text.ToString();
        }
        else
        {
            lblCareerShow.Text = "";
            Session["_Career"] = null;
        }
    }
    protected void chkOtherCareer_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkOtherCareer.Checked == true)
        {
            GetCareer = "Other".ToString();
            lblCareerShow.Text = GetCareer;
            Session["_Career"] = lblCareerShow.Text.ToString();
        }
        else
        {
            lblCareerShow.Text = "";
            Session["_Career"] = null;
        }
    }

    //Future Plan
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        if (this.CheckBox1.Checked == true)
        {
            GetFuturePlan = "Start a Business".ToString();
            lblPlanShow.Text = GetFuturePlan;
            Session["_FPlan"] = lblPlanShow.Text.ToString();
        }
        else
        {
            lblPlanShow.Text = "";
            Session["_FPlan"] = null;
        }
    }
    protected void CheckBox2_CheckedChanged(object sender, EventArgs e)
    {
        if (this.CheckBox2.Checked == true)
        {
            GetFuturePlan = "Work as an I.T. Professional".ToString();
            lblPlanShow.Text = GetFuturePlan;
            Session["_FPlan"] = lblPlanShow.Text.ToString();
        }
        else
        {
            lblPlanShow.Text = "";
            Session["_FPlan"] = null;
        }
    }
    protected void CheckBox3_CheckedChanged(object sender, EventArgs e)
    {
        if (this.CheckBox3.Checked == true)
        {
            GetFuturePlan = "Go Abroad".ToString();
            lblPlanShow.Text = GetFuturePlan;
            Session["_FPlan"] = lblPlanShow.Text.ToString();
        }
        else
        {
            lblPlanShow.Text = "";
            Session["_FPlan"] = null;
        }
    }
    protected void chkOtherFPlan_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkOtherFPlan.Checked == true)
        {
            GetFuturePlan = "Other".ToString();
            lblPlanShow.Text = GetFuturePlan;
            Session["_FPlan"] = lblPlanShow.Text.ToString();
        }
        else
        {
            lblPlanShow.Text = "";
            Session["_FPlan"] = null;
        }
    }

    //Mode of Knowing us
    protected void CheckBox4_CheckedChanged(object sender, EventArgs e)
    {
        if (this.CheckBox4.Checked == true)
        {
            GetModeKnow = "Seminar".ToString();
            lblKnowShow.Text = GetModeKnow;
            Session["_ModeKnow"] = lblKnowShow.Text.ToString();
        }
        else
        {
            lblKnowShow.Text = "";
            Session["_ModeKnow"] = null;
        }
    }
    protected void CheckBox5_CheckedChanged(object sender, EventArgs e)
    {
        if (this.CheckBox5.Checked == true)
        {
            GetModeKnow = "Cinema".ToString();
            lblKnowShow.Text = GetModeKnow;
            Session["_ModeKnow"] = lblKnowShow.Text.ToString();
        }
        else
        {
            lblKnowShow.Text = "";
            Session["_ModeKnow"] = null;
        }
    }
    protected void CheckBox6_CheckedChanged(object sender, EventArgs e)
    {
        if (this.CheckBox6.Checked == true)
        {
            GetModeKnow = "Newspaper".ToString();
            lblKnowShow.Text = GetModeKnow;
            Session["_ModeKnow"] = lblKnowShow.Text.ToString();
        }
        else
        {
            lblKnowShow.Text = "";
            Session["_ModeKnow"] = null;
        }
    }
    protected void CheckBox7_CheckedChanged(object sender, EventArgs e)
    {
        if (this.CheckBox7.Checked == true)
        {
            GetModeKnow = "Friends/Relatives".ToString();
            lblKnowShow.Text = GetModeKnow;
            Session["_ModeKnow"] = lblKnowShow.Text.ToString();
        }
        else
        {
            lblKnowShow.Text = "";
            Session["_ModeKnow"] = null;
        }
    }
    protected void CheckBox8_CheckedChanged(object sender, EventArgs e)
    {
        if (this.CheckBox8.Checked == true)
        {
            GetModeKnow = "Magazine".ToString();
            lblKnowShow.Text = GetModeKnow;
            Session["_ModeKnow"] = lblKnowShow.Text.ToString();
        }
        else
        {
            lblKnowShow.Text = "";
            Session["_ModeKnow"] = null;
        }
    }
    protected void CheckBox9_CheckedChanged(object sender, EventArgs e)
    {
        if (this.CheckBox9.Checked == true)
        {
            GetModeKnow = "Internet".ToString();
            lblKnowShow.Text = GetModeKnow;
            Session["_ModeKnow"] = lblKnowShow.Text.ToString();
        }
        else
        {
            lblKnowShow.Text = "";
            Session["_ModeKnow"] = null;
        }
    }
    protected void CheckBox10_CheckedChanged(object sender, EventArgs e)
    {
        if (this.CheckBox10.Checked == true)
        {
            GetModeKnow = "Existing Student".ToString();
            lblKnowShow.Text = GetModeKnow;
            Session["_ModeKnow"] = lblKnowShow.Text.ToString();
        }
        else
        {
            lblKnowShow.Text = "";
            Session["_ModeKnow"] = null;
        }
    }
    protected void CheckBox11_CheckedChanged(object sender, EventArgs e)
    {
        if (this.CheckBox10.Checked == true)
        {
            GetModeKnow = "Other".ToString();
            lblKnowShow.Text = GetModeKnow;
            Session["_ModeKnow"] = lblKnowShow.Text.ToString();
        }
        else
        {
            lblKnowShow.Text = "";
            Session["_ModeKnow"] = null;
        }
    }

    //I.T. PLacement
    protected void chkYes_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkYes.Checked == true)
        {
            GetPlacement = "YES".ToString();
            lblPlaceShow.Text = GetPlacement;
            Session["_ITPlacement"] = lblPlaceShow.Text.ToString();
        }
        else
        {
            lblPlaceShow.Text = "";
            Session["_ITPlacement"] = null;
        }
    }
    protected void chkNo_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkNo.Checked == true)
        {
            GetPlacement = "NO".ToString();
            lblPlaceShow.Text = GetPlacement;
            Session["_ITPlacement"] = lblPlaceShow.Text.ToString();
        }
        else
        {
            lblPlaceShow.Text = "";
            Session["_ITPlacement"] = null;
        }
    }

    //Gender
    protected void btnCloseModal_Click(object sender, EventArgs e)
    {
        Response.Redirect("Enquiry.aspx");
    }


    protected void btnSave_Click(object sender, EventArgs e)
    {

        EnquiryNo = this.txtEnquiryNo.Text.ToString();
        Title_ = this.dropTitle.Text.ToString();
        FullName = this.txtFullName.Text.ToString();
        Address = this.txtAddress.Text.ToString();
        DOB = this.txtDOB.Text.ToString();
        Gender = this.dropGender.Text.ToString();
        ContactNo = this.txtContact.Text.ToString();
        EmailID = this.txtEmail.Text.ToString();
        ParentName = this.txtGuardianName.Text.ToString();
        Education = Session["_Edu"].ToString();
        CareerField = Session["_Career"].ToString();
        FuturePlan = Session["_FPlan"].ToString();
        ModeOfKnow = Session["_ModeKnow"].ToString();
        ITPlacement = Session["_ITPlacement"].ToString();
        CreationDate = this.lblDate_Today.Text.ToString();
        CreatedBy = Session["_UserName_"].ToString();

        filePath = filUpload.PostedFile.FileName;
        filename = Path.GetFileName(filUpload.FileName);
        //fLoad.SaveAs(Server.MapPath("~/pix_Info/" + filename));
        ext = Path.GetExtension(filename);
        contenttype = String.Empty;


       // Label1.Text = Session["_Edu"].ToString();
        if (this.dropTitle.Text == "SELECT")
        {
            //Label1.Text = "Invalid Gender Selectect";
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('Invalid Title Selected');", true);
        }
        else if (this.dropGender.Text == "SELECT")
        {
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('Invalid Gender Selected');", true);
        }
        else if (this.txtContact.Text == "") 
        {
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('Please, this field cannot be empty. \\n...The Contact Number');", true);
        }
        else if (this.txtEmail.Text == "") 
        {
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('Please, this field cannot be empty. \\nE-Mail Address');", true);
        }
        else if (Session["_Edu"] == null)
        {
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('No Selection made for Education Yet!');", true);
        }
        else if (Session["_Career"] == null)
        {
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('No Selection made for Career Yet!');", true);
        }
        else if (Session["_FPlan"] == null)
        {
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('No Selection made for Future Plan Yet!');", true);
        }
        else if (Session["_ModeKnow"] == null)
        {
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('How does the student Know/Hear about Aptech?');", true);
        }
        else if (Session["_ITPlacement"] == null)
        {
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('Does the student Require IT Placement?');", true);
        }
        else
        {
            //upload passport here code;
            switch (ext)
            {
                case ".jpg":
                    contenttype = "image/jpg";
                    break;
                case ".png":
                    contenttype = "image/png";
                    break;
                case ".JPEG":
                    contenttype = "image/jpeg";
                    break;
                default:
                    ClientScript.RegisterStartupScript(GetType(), "alert", "alert('File" + " (" + filename + ") " + "not recognised." + " Upload Image formats \\nPlease check your entry and try Again');", true);
                    break;
            }
            if (contenttype != String.Empty && this.filUpload.HasFile)
            {
                string str = filUpload.FileName;
                filUpload.PostedFile.SaveAs(Server.MapPath("~/Passport/" + str));
                string Image = str.ToString();
                //string name = txtCaption.Text;  

                SqlConnection con = new SqlConnection(@"Data Source=KODEXPROGRAMMIN;Initial Catalog=AptechRecord_DB;Integrated Security=SSPI; User ID=sa; Password=Digital10; Encrypt=True;TrustServerCertificate=True");

                //SqlCommand cmd = new SqlCommand("insert into tbl_data values(@name,@Image)", con);
                SqlCommand cmd = new SqlCommand("INSERT INTO Passport_tbl VALUES (@ContactNo, @EmailID, @DataContent)", con);
                         cmd.Parameters.AddWithValue("@ContactNo", ContactNo);
                         cmd.Parameters.AddWithValue("@EmailID", EmailID);
                         cmd.Parameters.AddWithValue("@DataContent", Image);

                con.Open();
                cmd.ExecuteNonQuery();

                con.Close();

            }
            else
            {
                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Passport Not Uploaded, Try again Later!');", true);
            }

            //End of passport upoad code
            //=====================================================================================================================================================

            string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constring))
            {
                using (SqlCommand cmd = new SqlCommand("INSERT INTO Enquiry_tbl (EnquiryNo, Title, FullName, Address, DOB, Gender, ContactNo, EmailID, ParentName, Education, CareerField, FuturePlan, ModeOfKnow, ITPlacement, CreationDate, CreatedBy) VALUES (@EnquiryNo, @Title, @FullName, @Address, @DOB, @Gender, @ContactNo, @EmailID, @ParentName, @Education, @CareerField, @FuturePlan, @ModeOfKnow, @ITPlacement, @CreationDate, @CreatedBy)", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@EnquiryNo", EnquiryNo.Trim());
                    cmd.Parameters.AddWithValue("@Title", Title_.Trim());
                    cmd.Parameters.AddWithValue("@FullName", FullName.Trim());
                    cmd.Parameters.AddWithValue("@Address", Address.Trim());
                    cmd.Parameters.AddWithValue("@DOB", DOB.Trim());
                    cmd.Parameters.AddWithValue("@Gender", Gender.Trim());
                    cmd.Parameters.AddWithValue("@ContactNo", ContactNo.Trim());
                    cmd.Parameters.AddWithValue("@EmailID", EmailID.Trim());
                    cmd.Parameters.AddWithValue("@ParentName", ParentName.Trim());
                    cmd.Parameters.AddWithValue("@Education", Education.Trim());
                    cmd.Parameters.AddWithValue("@CareerField", CareerField.Trim());
                    cmd.Parameters.AddWithValue("@FuturePlan", FuturePlan.Trim());
                    cmd.Parameters.AddWithValue("@ModeOfKnow", ModeOfKnow.Trim());
                    cmd.Parameters.AddWithValue("@ITPlacement", ITPlacement.Trim());
                    cmd.Parameters.AddWithValue("@CreationDate", CreationDate.Trim());
                    cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy.Trim());
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    Response.Redirect("Success_Enquiry.aspx");
                    Session.RemoveAll();


                   // this.UploadPassport();

                   // Label1.Text = "Data Save Successfully and Recorded";

                    con.Close();

                }
            }
        }
    }
}