﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;
using System.IO;

public partial class _sector101_StaffRegistration : System.Web.UI.Page
{
    public string F_NAME, L_NAME, STAFF_ID, MOBILE_NO, DESIGNATION, REG_DATE;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (this.dropDesignation.Text == "Select your Designation...") 
        {
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('What COURSE is the Student applying for?');", true);
        }
        else
        {
            //ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('Good to Go');", true);

           F_NAME = this.txtFN.Text.ToString();
           L_NAME = this.txtLN.Text.ToString();
           STAFF_ID = this.txtID.Text.ToString();
           MOBILE_NO = txtMobileMo.Text.ToString();
           DESIGNATION = this.dropDesignation.Text.ToString();
           REG_DATE = System.DateTime.Now.ToLongDateString();

           Session["_StaffName"] = L_NAME + " " + F_NAME;


            string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constring))
            {
                using (SqlCommand cmd = new SqlCommand("INSERT INTO Staff_Registration_tbl (F_NAME, L_NAME, STAFF_ID, MOBILE_NO, DESIGNATION, REG_DATE) VALUES (@F_NAME, @L_NAME, @STAFF_ID, @MOBILE_NO, @DESIGNATION, @REG_DATE)", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@F_NAME", F_NAME.Trim());
                    cmd.Parameters.AddWithValue("@L_NAME", L_NAME.Trim());
                    cmd.Parameters.AddWithValue("@STAFF_ID", STAFF_ID.Trim());
                    cmd.Parameters.AddWithValue("@MOBILE_NO", MOBILE_NO.Trim());
                    cmd.Parameters.AddWithValue("@DESIGNATION", DESIGNATION.Trim());
                    cmd.Parameters.AddWithValue("@REG_DATE", REG_DATE.Trim());
                    //cmd.Parameters.AddWithValue("@GENDER", GENDER.Trim());
                    //cmd.Parameters.AddWithValue("@CONTACTNO", CONTACTNO.Trim());
                    //cmd.Parameters.AddWithValue("@P_ADDRESS", P_ADDRESS.Trim());
                    //cmd.Parameters.AddWithValue("@EMAIL_1", EMAIL_1.Trim());
                    //cmd.Parameters.AddWithValue("@EMAIL_2", EMAIL_2.Trim());
                    //cmd.Parameters.AddWithValue("@EDUCATION", EDUCATION.Trim());
                    //cmd.Parameters.AddWithValue("@XCURRICULUM", XCURRICULUM.Trim());
                    //cmd.Parameters.AddWithValue("@CREATEDDATE", CREATEDDATE.Trim());
                    //cmd.Parameters.AddWithValue("@CreationDate", CreationDate.Trim());
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    Response.Redirect("StaffSignUpSuccess.aspx");
                    Session.RemoveAll();

                    // Label1.Text = "Data Save Successfully and Recorded";

                    con.Close();

                }
            }
        }
    }
}