﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;
using System.Web.Services;

public partial class SearchResult : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            this.lblKeyword.Text = Session["Keyword"].ToString();

            //this.Validate_Enquiry();
            //this.Validate_Application();
            //this.Validate_Registration();

            SearchResults_For_Enquiry();
            SearchResults_For_Registration();
            SearchResults_For_Application();
        }
    }

    private void SearchResults_For_Enquiry()
    {
        string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        using (SqlConnection cn = new SqlConnection(constring))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT [FullName],[EnquiryNo],[Address],[ParentName],[CreatedBy],[CreationDate],[ContactNo] FROM Enquiry_tbl WHERE ContactNo ='" + this.lblKeyword.Text.Trim() + "'", cn))
            //("SELECT MAX (patient_id) as max_patient_id FROM patient_data ", cnz);
            {
                cmd.CommandType = CommandType.Text;
                cn.Open();
                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                RepDetails.DataSource = ds;
                RepDetails.DataBind();
                cn.Close();

                this.Validate_Enquiry();
            }
        }
    }

    private void SearchResults_For_Registration()
    {
        string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        using (SqlConnection cn = new SqlConnection(constring))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT [SERIALNO],[EDUCATION],[CONTACTNO],[CREATEDBY],[CREATEDDATE] FROM RegistrationStudent_tbl WHERE CONTACTNO ='" + this.lblKeyword.Text.Trim() + "'", cn))
            //("SELECT MAX (patient_id) as max_patient_id FROM patient_data ", cnz);
            {
                cmd.CommandType = CommandType.Text;
                cn.Open();
                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                Repeater2.DataSource = ds;
                Repeater2.DataBind();
                cn.Close();

                this.Validate_Registration();
            }
        }
    }

    private void SearchResults_For_Application()
    {
        string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        using (SqlConnection cn = new SqlConnection(constring))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT [FULLNAME],[SERIALNO],[COURSEAPPLIED],[P_ADDRESS],[XCURRICULUM],[CREATEDBY],[CREATEDDATE],[CONTACTNO] FROM Application_tbl WHERE CONTACTNO ='" + this.lblKeyword.Text.Trim() + "'", cn))
            //("SELECT MAX (patient_id) as max_patient_id FROM patient_data ", cnz);
            {
                cmd.CommandType = CommandType.Text;
                cn.Open();
                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                Repeater1.DataSource = ds;
                Repeater1.DataBind();
                cn.Close();


                Validate_Application();
            }
        }
    }

    private void Validate_Enquiry()
    {
        string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        using (SqlConnection cn = new SqlConnection(constring))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT [ContactNo] FROM Enquiry_tbl WHERE ContactNo ='" + this.lblKeyword.Text.Trim() + "'", cn))
            {
                cmd.CommandType = CommandType.Text;
                cn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows == true)
                {
                   // this.SearchResults_For_Registration();
                    this.pnlEnquiry.Visible = true;
                }
                else
                {
                    //this.pnlEnquiry.Visible = false;
                    this.lblEnquiryInfo.Visible = true;
                    //ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Invalid Login Detail.\\nLogin Failed!');", true);
                }


            }
            cn.Close();  //SELECT * FROM `student` WHERE mark=(select max(mark) from student) &  SELECT MIN( price ) FROM table WHERE price > ( SELECT MIN( price ) FROM table )
        }
    }

    private void Validate_Application()
    {
        string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        using (SqlConnection cn = new SqlConnection(constring))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT [CONTACTNO] FROM Application_tbl WHERE CONTACTNO ='" + this.lblKeyword.Text.Trim() + "'", cn))
            {
                cmd.CommandType = CommandType.Text;
                cn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows == true)
                {
                    //this.SearchResults_For_Application();
                    this.pnlApplication.Visible = true; 
                }
                else
                {
                   // this.pnlApplication.Visible = true;
                    this.lblApplicationInfo.Visible = true;
                    //ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Invalid Login Detail.\\nLogin Failed!');", true);
                }


            }
            cn.Close();  //SELECT * FROM `student` WHERE mark=(select max(mark) from student) &  SELECT MIN( price ) FROM table WHERE price > ( SELECT MIN( price ) FROM table )
        }
    }

    private void Validate_Registration()
    {
        string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        using (SqlConnection cn = new SqlConnection(constring))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT [CONTACTNO] FROM RegistrationStudent_tbl WHERE CONTACTNO ='" + this.lblKeyword.Text.Trim() + "'", cn))
            {
                cmd.CommandType = CommandType.Text;
                cn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows == true)
                {
                    //this.SearchResults_For_Registration();
                    this.pnlRegistration.Visible = true; 
                }
                else
                {
                   // this.pnlRegistration.Visible = false;
                    this.lblRegInfo.Visible = true; 
                    //ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Invalid Login Detail.\\nLogin Failed!');", true);
                }


            }
            cn.Close();  //SELECT * FROM `student` WHERE mark=(select max(mark) from student) &  SELECT MIN( price ) FROM table WHERE price > ( SELECT MIN( price ) FROM table )
        }
    }
}