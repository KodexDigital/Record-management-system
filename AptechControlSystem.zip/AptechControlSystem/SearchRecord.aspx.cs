﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;
using System.Web.Services;


public partial class SearchRecord : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            this.txtSearch.Focus();
            this.txtSearch.Text = "";
        }
    }
    protected void txtSearch_TextChanged(object sender, EventArgs e)
    {

        //Session["Keyword"] = this.txtSearch.Text.ToString();
        


        string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        using (SqlConnection cn = new SqlConnection(constring))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT ContactNo,FullName FROM Enquiry_tbl WHERE FullName ='" + txtSearch.Text.Trim() + "' OR ContactNo ='" + txtSearch.Text.Trim() + "'", cn))
            {
                cmd.CommandType = CommandType.Text;
                cn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows == true)
                {
                    dr.Read();
                    Session["Keyword"] = dr["ContactNo"].ToString();
                    Response.Redirect("SearchResult.aspx");
                    Session.RemoveAll();
                }

            }
            cn.Close();  //SELECT * FROM `student` WHERE mark=(select max(mark) from student) &  SELECT MIN( price ) FROM table WHERE price > ( SELECT MIN( price ) FROM table )
        }

    }

    //public string Number;
    [System.Web.Script.Services.ScriptMethod()]
    [System.Web.Services.WebMethod]
    public static List<string> SearchStudent(string prefixText, int count)
    {
        using (SqlConnection conn = new SqlConnection())
        {
            conn.ConnectionString = ConfigurationManager
                    .ConnectionStrings["ConString"].ConnectionString;
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "SELECT FullName, ContactNo FROM Enquiry_tbl WHERE FullName like @SearchText + '%' OR ContactNo Like @SearchText + '%'";
                cmd.Parameters.AddWithValue("@SearchText", prefixText);
                cmd.Connection = conn;
                conn.Open();
                List<string> customers = new List<string>();
                using (SqlDataReader sdr = cmd.ExecuteReader())
                {
                    while (sdr.Read())
                    {
                        sdr.Read();
                        customers.Add(sdr["FullName"].ToString());
                    }
                }
                conn.Close();
                return customers;
            }
        }
    }
    //private void GetData()
    //{

    //    string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
    //    using (SqlConnection cn = new SqlConnection(constring))
    //    {
    //        using (SqlCommand cmd = new SqlCommand("SELECT ContactNo FROM Enquiry_tbl WHERE ContactNo ='" + txtSearch.Text.Trim() + "'", cn))
    //        {
    //            0 //SELECT * FROM `student` WHERE mark=(select max(mark) from student) &  SELECT MIN( price ) FROM table WHERE price > ( SELECT MIN( price ) FROM table )
    //    }
    //}

}