﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;
using System.IO;
public partial class Update_RegistrationForm : System.Web.UI.Page
{
    public string filePath;
    public string filename;
    public string ext;
    public string contenttype;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {

            this.lblInfo.Text = "";
        }
    }
    protected void btnUpdatePix_Click(object sender, EventArgs e)
    {
        if (this.txtContact_.Text == "")
        {
            //ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Enter the contact number for verification!');", true);
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('Enter the contact number for verification!');", true);
            this.lblInfo.Text = "Enter the contact number for verification!";
        }
        else if (this.txtEmail_.Text == "")
        {
            //ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Enter the student's E-mail Address for verification!');", true);
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('Enter the student's E-mail Address for verification!');", true);
            this.lblInfo.Text = "Enter the student's E-mail Address for verification!";
        }
        else
        {
            string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            using (SqlConnection cn = new SqlConnection(constring))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM Passport_tbl  WHERE ContactNo ='" + txtContact_.Text.ToString() + "' OR EmailID ='" + txtEmail_.Text.ToString() + "' ", cn))
                {
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.HasRows == true)
                    {
                        //dr.Read(); 
                        string msg = txtContact_.Text.ToString() + " " + "with" + " " + txtEmail_.Text.ToString() + " Has been preupdated initially.";
                        //ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + msg + "');", true);
                        ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('" + msg + "');", true);
                        this.lblInfo.Text = msg.ToString();

                    }
                    else
                    {
                        //ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Record not Found - It does not exist!');", true);
                        this.ValidateData();
                    }


                }
                cn.Close();  //SELECT * FROM `student` WHERE mark=(select max(mark) from student) &  SELECT MIN( price ) FROM table WHERE price > ( SELECT MIN( price ) FROM table )
            }
        }

    }

    private void ValidateData()
    {
        string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        using (SqlConnection cn = new SqlConnection(constring))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT * FROM RegistrationStudent_tbl WHERE CONTACTNO ='" + txtContact_.Text.ToString() + "' OR EMAIL='" + txtEmail_.Text.ToString() + "'", cn))
            {
                cmd.CommandType = CommandType.Text;
                cn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows == true)
                {
                    this.uploadPassport();

                }
                else
                {
                    string msg = txtContact_.Text.ToString() + " " + "with" + " " + txtEmail_.Text.ToString() + " Does not exist in our Records.";
                    //ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + msg + "');", true);
                    ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('" + msg + "');", true);
                    this.lblInfo.Text = msg.ToString();

                }


            }
            cn.Close();  //SELECT * FROM `student` WHERE mark=(select max(mark) from student) &  SELECT MIN( price ) FROM table WHERE price > ( SELECT MIN( price ) FROM table )
        }
    }

    private void uploadPassport()
    {
        filePath = filUpload.PostedFile.FileName;
        filename = Path.GetFileName(filUpload.FileName);
        //fLoad.SaveAs(Server.MapPath("~/pix_Info/" + filename));
        ext = Path.GetExtension(filename);
        contenttype = String.Empty;

        //upload passport here code;
        switch (ext)
        {
            case ".jpg":
                contenttype = "image/jpg";
                break;
            case ".jpeg":
                contenttype = "image/jpeg";
                break;
            case ".png":
                contenttype = "image/png";
                break;
            case ".JPEG":
                contenttype = "image/JPEG";
                break;
            default:
                ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('File" + " (" + filename + ") " + "not recognised." + " Upload Image formats \\nPlease check your entry and try Again');", true);
                //this.lblInfo.Text = "Enter the contact number for verification!";
                break;
        }
        if (contenttype != String.Empty && this.filUpload.HasFile)
        {
            string str = filUpload.FileName;
            filUpload.PostedFile.SaveAs(Server.MapPath("~/Passport/" + str));
            string Image = str.ToString();
            //string name = txtCaption.Text;  

            SqlConnection con = new SqlConnection(@"Data Source=KODEXPROGRAMMIN;Initial Catalog=AptechRecord_DB;Integrated Security=SSPI; User ID=sa; Password=Digital10; Encrypt=True;TrustServerCertificate=True");

            //SqlCommand cmd = new SqlCommand("insert into tbl_data values(@name,@Image)", con);
            SqlCommand cmd = new SqlCommand("INSERT INTO Passport_tbl VALUES (@ContactNo, @EmailID, @DataContent)", con);
            cmd.Parameters.AddWithValue("@ContactNo", this.txtContact_.Text.Trim());
            cmd.Parameters.AddWithValue("@EmailID", this.txtEmail_.Text.Trim());
            cmd.Parameters.AddWithValue("@DataContent", Image);

            con.Open();
            cmd.ExecuteNonQuery();

            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('Passport Uploaded and Updated Successfully!');", true);
            this.lblInfo.Text = "Passport Uploaded and Updated Successfully!";

            con.Close();

        }
        else
        {
            //ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Passport Not Uploaded, Try again Later!');", true);
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('Passport Not Uploaded, Try again Later!');", true);
            this.lblInfo.Text = "Passport Not Uploaded, Try again Later!";
        }
    }
    protected void btnUpdateReg_Click(object sender, EventArgs e)
    {
        if (this.txt_Contact.Text == "")
        {
            //ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Please, enter the contact number of the student!');", true);
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('Please, enter the contact number of the student!');", true);
            this.lblInfo.Text = "Please, enter the contact number of the student!";
        }
        else if (this.txt_Email.Text == "")
        {
            //ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Student's E-mail ID to continue, please!');", true);
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('Student's E-mail ID to continue, please!');", true);
            this.lblInfo.Text = "Student's E-mail ID to continue, please!";
        }
        else if (this.txtReg.Text == "")
        {
            //ClientScript.RegisterStartupScript(GetType(), "alert", "alert('The Enquiry Number should be entered, for update.!');", true);
            ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('The Enquiry Number should be entered, for update!');", true);
            this.lblInfo.Text = "The Serial Number should be entered, for update!";
        }
        else
        {
            string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            using (SqlConnection cn = new SqlConnection(constring))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM RegistrationStudent_tbl  WHERE CONTACTNO ='" + txt_Contact.Text.ToString() + "' OR EMAIL='" + txt_Email.Text.ToString() + "' ", cn))
                {
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.HasRows == true)
                    {
                        //dr.Read();

                        this.updateEnquiryNo();
                        string msg = "Serial Number Updated Succesfully";
                        ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('Serial Number Updated Succesfully');", true);
                        this.lblInfo.Text = msg.ToString();

                    }
                    else
                    {
                        string msg = txt_Contact.Text.ToString() + " " + "with" + " " + txt_Email.Text.ToString() + " Never existed in our Records.";
                        ClientScript.RegisterStartupScript(GetType(), "AlertBox", "alert('" + msg + "');", true);
                        this.lblInfo.Text = msg.ToString();
                    }


                }
                cn.Close();  //SELECT * FROM `student` WHERE mark=(select max(mark) from student) &  SELECT MIN( price ) FROM table WHERE price > ( SELECT MIN( price ) FROM table )
            }
        }

    }

    private void updateEnquiryNo()
    {

        string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constring))
        {
            using (SqlCommand cmd = new SqlCommand("UPDATE RegistrationStudent_tbl SET SERIALNO = '" + txtReg.Text.ToString() + "'  WHERE CONTACTNO ='" + txt_Contact.Text.ToString() + "' OR EMAIL='" + txt_Email.Text.ToString() + "'", con))
            {
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@SERIALNO", this.txtReg.Text.ToString());
                con.Open();
                int rowsAffected = cmd.ExecuteNonQuery();

                con.Close();
            }

        }
    }
}