﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Account_01_ServerRedirect : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.Timer1.Interval = 15000;
    }
    protected void Timer1_Tick(object sender, EventArgs e)
    {
        if (this.Timer1.Interval == 15000)
        {
            this.Timer1.Enabled = false;
            Response.Redirect("Default.aspx");
            Session.RemoveAll();
        }
    }
}