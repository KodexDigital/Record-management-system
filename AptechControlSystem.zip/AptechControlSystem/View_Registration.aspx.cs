﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;
using System.IO;


public partial class View_Registration : System.Web.UI.Page
{
    SqlDataAdapter da;
    DataSet ds;
    int i = 0;
    int j;
    int last;

    public string filePath;
    public string filename;
    public string ext;
    public string contenttype;

    public string UpdateHolder;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!this.IsPostBack)
        {
            this.lblSessionName.Text = "WELCOME, " + Session["_Designation_"].ToString() + " " + "[" + Session["_UserName_"].ToString() + "]" + ":" + System.DateTime.Now.ToLongDateString() + ".";

            this.BindData();

            this.ViewAllRecord();
            // this.ViewPassport();
        }
    }
    private void BindData()
    {
        try
        {
            string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            using (SqlConnection cn = new SqlConnection(constring))
            {
                cn.Open();
                da = new SqlDataAdapter("SELECT SERIALNO, COURSEAPPLIED, TITLE, FULLNAME, ADDRESS, DOB, GENDER, CONTACTNO, EMAIL, EDUCATION, XCRURRICULUM, FACEBOOK, INTAGRAM, LINKED_IN, WHATSAPP, KNOWMODE, CREATEDDATE FROM RegistrationStudent_tbl", cn);
                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                ds = new DataSet();
                da.Fill(ds, "RegistrationStudent_tbl");
                // dataGridView1.DataSource = ds.Tables["emp"]
            }
            if (ds.Tables[0].Rows.Count > 0)
            {
                i = 0;
                this.txtTitle.Text = ds.Tables[0].Rows[i]["TITLE"].ToString();
                this.txtSerialNo.Text = ds.Tables[0].Rows[i]["SERIALNO"].ToString();
                this.txtFName.Text = ds.Tables[0].Rows[i]["FULLNAME"].ToString();
                this.txtCourse.Text = ds.Tables[0].Rows[i]["COURSEAPPLIED"].ToString();
                this.txtAddress.Text = ds.Tables[0].Rows[i]["ADDRESS"].ToString();
                this.txtDOB.Text = ds.Tables[0].Rows[i]["DOB"].ToString();
                this.txtGender.Text = ds.Tables[0].Rows[i]["GENDER"].ToString();
                this.txtNo.Text = ds.Tables[0].Rows[i]["CONTACTNO"].ToString();
                this.txtEmail.Text = ds.Tables[0].Rows[i]["EMAIL"].ToString();
                this.txtEdu.Text = ds.Tables[0].Rows[i]["EDUCATION"].ToString();
                this.txtXcurriculum.Text = ds.Tables[0].Rows[i]["XCRURRICULUM"].ToString();
                this.txtFB.Text = ds.Tables[0].Rows[i]["FACEBOOK"].ToString();
                this.txtInstagram.Text = ds.Tables[0].Rows[i]["INTAGRAM"].ToString(); 
                this.txtLinked.Text = ds.Tables[0].Rows[i]["LINKED_IN"].ToString();
                this.txtWhatsapp.Text = ds.Tables[0].Rows[i]["WHATSAPP"].ToString();
                this.txtModeKnow.Text = ds.Tables[0].Rows[i]["KNOWMODE"].ToString();  
                this.txtRegDate.Text = ds.Tables[0].Rows[i]["CREATEDDATE"].ToString();
            }
        }
        catch (SqlException ex)
        {
            ClientScript.RegisterClientScriptBlock((GetType()), "AlertBox", "alert('" + ex.ToString() + "');", true);
        }

        {
            string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            using (SqlConnection cn = new SqlConnection(constring))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) AS TotalReg FROM RegistrationStudent_tbl ", cn))
                {
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.HasRows == true)
                    {
                        dr.Read();
                        this.lblCountAll.Text = dr["TotalReg"].ToString();
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Record not Found - It does not exist!');", true);
                    }


                }
                cn.Close();  //SELECT * FROM `student` WHERE mark=(select max(mark) from student) &  SELECT MIN( price ) FROM table WHERE price > ( SELECT MIN( price ) FROM table )
            }
        }
    }
    private void ViewAllRecord()
    {
        string constr = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        string query = "SELECT SERIALNO, COURSEAPPLIED, TITLE, FULLNAME, ADDRESS, DOB, GENDER, CONTACTNO, EMAIL, EDUCATION, XCRURRICULUM, FACEBOOK, INTAGRAM, LINKED_IN, WHATSAPP, KNOWMODE FROM RegistrationStudent_tbl ORDER BY SN ASC";

        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand(query))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.Connection = con;
                    sda.SelectCommand = cmd;
                    using (DataSet ds = new DataSet())
                    {
                        sda.Fill(ds);
                        gridViewAll.DataSource = ds.Tables[0];
                        gridViewAll.DataBind();
                    }
                }
            }
        }
    }

    private void ViewPassport()
    {
        string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        using (SqlConnection cn = new SqlConnection(constring))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT DataContent FROM Passport_tbl WHERE ContactNo ='" + txtSearch.Text.ToString() + "' OR EmailID='" + txtSearch.Text.ToString() + "' ", cn))
            {
                cn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    string imagename = dr["DataContent"].ToString();
                    imgPassort.ImageUrl = "~/Passport/" + imagename;

                }
                else
                {
                    imgPassort.ImageUrl = null;
                    ClientScript.RegisterClientScriptBlock(GetType(), "AlertBox", "alert('Passport not found. Not Uploaded Yet,...');", true);
                    //ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Record not Found - It does not exist!');", true);
                }
            }
            cn.Close();
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        if (this.txtSearch.Text == "")
        {
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('I cannot search am empty parameter for you!\\nPlease, double check your search and try again!');", true);
        }
        else
        {
            string constring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            using (SqlConnection cn = new SqlConnection(constring))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT SERIALNO, COURSEAPPLIED, TITLE, FULLNAME, ADDRESS, DOB, GENDER, CONTACTNO, EMAIL, EDUCATION, XCRURRICULUM, FACEBOOK, INTAGRAM, LINKED_IN, WHATSAPP, KNOWMODE, CREATEDDATE FROM RegistrationStudent_tbl  WHERE CONTACTNO ='" + txtSearch.Text.ToString() + "' OR EMAIL='" + txtSearch.Text.ToString() + "' ", cn))
                {
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.HasRows == true)
                    {
                        dr.Read();
                        this.txtTitle.Text = dr["TITLE"].ToString();
                        this.txtSerialNo.Text = dr["SERIALNO"].ToString();
                        this.txtFName.Text = dr["FULLNAME"].ToString();
                        this.txtCourse.Text = dr["COURSEAPPLIED"].ToString();
                        this.txtAddress.Text = dr["ADDRESS"].ToString();
                        this.txtDOB.Text = dr["DOB"].ToString();
                        this.txtGender.Text = dr["GENDER"].ToString();
                        this.txtNo.Text = dr["CONTACTNO"].ToString();
                        this.txtEmail.Text = dr["EMAIL"].ToString();
                        this.txtEdu.Text = dr["EDUCATION"].ToString();
                        this.txtXcurriculum.Text = dr["XCRURRICULUM"].ToString();
                        this.txtFB.Text = dr["FACEBOOK"].ToString();
                        this.txtInstagram.Text = dr["INTAGRAM"].ToString(); 
                        this.txtLinked.Text = dr["LINKED_IN"].ToString();
                        this.txtWhatsapp.Text = dr["WHATSAPP"].ToString();
                        this.txtModeKnow.Text = dr["KNOWMODE"].ToString();  
                        this.txtRegDate.Text = dr["CREATEDDATE"].ToString();


                        //Viewing Passport
                        this.ViewPassport();

                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Record not Found - It does not exist!');", true);
                    }


                }
                cn.Close();  //SELECT * FROM `student` WHERE mark=(select max(mark) from student) &  SELECT MIN( price ) FROM table WHERE price > ( SELECT MIN( price ) FROM table )
            }
        }
    }
    

}